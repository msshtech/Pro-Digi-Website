// data.json
import person from "../src/assets/person.png";
const sliderData= [
    {
      "image": person,
      "name": "tester1",
      "date": "21st Sep, 2023",
      "content": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    {
      "image": person,
      "name": "tester2",
      "date": "25th Dec, 2023",
      "content": "t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to"
    },

    {
        "image": person,
        "name": "tester3",
        "date": "21st Sep, 2023",
        "content": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
      },
      {
        "image": person,
        "name": "tester4",
        "date": "25th Dec, 2023",
        "content": "t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to"
      },
    // Add more slides as needed
  ]

export default sliderData;
  